int pow(int a, int b){
	int res;
	res = 1;
	while(b){
		res = res * a;
		b = b - 1;
	}
	return b;
}

int main(){
	int arr[32];

	int var1, var2, var;
	var = var1*var2;
	while(var1 - var2){
		var;
	}
	var = arr[5];
	pow(var1, var2);
}